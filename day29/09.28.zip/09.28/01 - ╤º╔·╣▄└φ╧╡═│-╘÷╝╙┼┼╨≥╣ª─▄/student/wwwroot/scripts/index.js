// index.js

var currentPage = 1;  //当前页
var sortProperty = 'createTime'; //排序属性
var sortDir      = -1; // 升序or降序

// 监听事件失败！原因是：
// 表格数据是通过Ajax请求得到的，
// 下面的代码执行时Ajax请求还没有发起
// th表头根本不存在
// $('th[sortBy]').click(function(){
//     alert($(this).attr('sortBy'))
// })

// 监测属性是sortBy的th元素
// 使用委托事件可以监听还不存在标签元素的事件
// 事件处理函数中的this指向还是激发事件的标签元素
$('.data').delegate('th[sortBy]', 'click', function(){
    // 取得属性是sortBy的值
    // 1 createTime
    // 2 age
    var p = $(this).attr('sortBy');
    console.log(p);
    // 如果点击的是"createTime"
    if(p == sortProperty){
        sortDir *= -1;
    }
    else{
        // 如果点击的不是"createTime",把被点击元素的sortBy属性值赋值给sortProperty
        sortProperty = p;
        sortDir = 1;
    }
    // 
    showPage(currentPage);
    console.log(sortDir);
})

// 删除一个学生
function removeStudent(id, name) {
    $('#removeModal .modal-body').text('点击确定将删除' + name);
    $('#removeModal').modal();
    
    $('#removeModal .btn-danger')
    .off('click')                   //移除所有点击事件监听函数
    .on('click', function(){        //添加一个点击事件监听函数
        $.post(
            '/api/student/remove/' + id,
            null,
            function(res){
                if(res.code == 'success'){
                    location.reload();
                }
                else{
                    alert(res.message);
                }
            }
        )
    })
}

// 显示第几页学生信息
function showPage(page){
    
    // $('form'):搜索模态框表单
    // $('form').serialize()将表单数据序列化成字符串，不方便进一步加工
    // $('form').serializeArray()将表单数据序列成数组，可以很方便地加入新数据
    var data = $('form').serializeArray();
    console.log(data);
    // 向data中插入排序的标志
    data.push({name:'sortProperty', value:sortProperty});
    data.push({name:'sortDir', value:sortDir});
    // 向服务器发起请求
    $.post(
        '/api/index/' + page,
        data,
        function(res){
            currentPage = res.data.page;
            // 如果请求数据成功则渲染模板table-template
            // 这样首页学生信息就显示出来了
            if(res.code == 'success'){
                var html = template('table-template', res.data);
                // 把学生信息显示到类名是data的元素中(即div)
                $('.data').html(html);
                
                // 添加"向上"或"向下"箭头图标
                // sortDir == 1时是升序
                // sortDir != 1时是降序
                $('<span class="glyphicon glyphicon-arrow-' + 
                    (sortDir == 1 ? 'up' : 'down') + '"></span>')
                    .appendTo('th[sortBy=' + sortProperty + ']');
            }
            else{
                alert(res.message);
            }
        }
    )
}

// 默认显示第1页
showPage(1);