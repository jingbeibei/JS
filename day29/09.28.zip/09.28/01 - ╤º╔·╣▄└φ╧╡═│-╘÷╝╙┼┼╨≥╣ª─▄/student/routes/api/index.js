// index.js

const   express = require('express'),
        Student = require('../../mongoose');
  
function formatTime(t){
    var M = t.getMonth() + 1,
    d = t.getDate(),
    h = t.getHours(),
    m = t.getMinutes();

    M = M < 10 ? '0' + M : M
    d = d < 10 ? '0' + d : d
    h = h < 10 ? '0' + h : h
    m = m < 10 ? '0' + m : m
    
    return t.getFullYear() + '-' + M + '-' + d + ' ' + h + ':' + m
}

// getPages()的作用是得到一共有几页  
function getPages(page, pageCount){
    var pages = [page]

    // 左边的第1个页码
    var left = page - 1
    // 右边的第1个页码
    var right = page + 1
    
    // 左边最多允许显示多少个
    // 如果右侧有充足的页码可以显示，左侧最多5个
    // 如果右侧页码不够5个，左侧可以多显示
    // var leftMaxCount = pageCount - page >= 5 ? 5 : 11 - (1 + pageCount - page)
    
    // while (left >= 1 && leftMaxCount-- > 0) {
    //     pages.unshift(left--)
    // }
    
    // while (right <= pageCount && pages.length < 11){
    //     pages.push(right++)
    // }
    
    
    // 左右两边各加1个页码，直到页码够11个或
    // 左边到1、右边到总页数
    while(pages.length < 11 && (left >= 1 || right <= pageCount)){
        if(left > 0) pages.unshift(left--)
        if(right <= pageCount) pages.push(right++)
    }
    console.log(pages + 'pagessssssss')
    // 返回是1个数组
    return pages
}

// 创建路由 
const route = express.Router()

// 处理应该显示第几页的学生信息
// /(:page)?表示处理以page结尾的请求
route.post('/(:page)?', (req, res) => {
    
    // console.log(getPages(12, 72))
    // console.log(getPages(3, 72))
    // console.log(getPages(70, 72))
    
    console.log(req.body)
    // 空对象
    var filter = {}
    // 获取要搜索的学生姓名
    var name = req.body.name
    // 如果name有值的话
    if(name){
        // 去除前后空格
        name = name.trim()
        if(name.length > 0){
            filter.name = {
                '$regex': `.*?${name}.*?`
                // 正则表达式：
                // .表示除回车换行外的任意字符
                // *表示0个或多个
                // ?表示可以有也可以没有
            }
            console.log(filter.name)
        }
    }
    // 处理按"性别"搜索
    var isMale = req.body.isMale
    if(isMale){
        isMale = isMale.trim()
        if(isMale.length > 0){
            filter.isMale = isMale == 'true'
        }
    }
    // 按"电话号码"搜索
    var phone = req.body.phone
    if(phone){
        phone = phone.trim()
        if(phone.length > 0){
            filter.phone = {
                '$regex': `.*?${phone}.*?`
            }
        }
    }
    
    // 空对象,存放排序后的学生信息
    var order = {}
    // 向order中放入一对值,
    // 属性名是:req.body.sortProperty
    // 属性值是:req.body.sortDir
    order[req.body.sortProperty] = req.body.sortDir
    // 使用[]为对象创建属性，属性名是[]内表达式的值
    // 如：req.body.sortProperty是值是createTime，则相当于：
    // order.createTime = 1
    
    // page表示当前显示的是第几页
    var page = req.params.page
    console.log(page+'page')
    page = page || 1
    
    page = parseInt(page)
    
    // 规定每页显示5条学生信息
    var pageSize = 5
    // find()是mongoose中的方法
    Student.find(filter).count((err, total) => {
        // console.log(total)
        
        if(err){
            res.json({code: 'error', message: '系统错误！'})
        }
        else{
            // 得到一共有几页
            var pageCount = Math.ceil(total / pageSize)
            
            if(page > pageCount) page = pageCount
            if(page < 1) page = 1
            // 查找学生信息并排序
            // sort()是排序函数
            Student.find(filter)
            .sort(order)
            .skip((page - 1) * pageSize)
            .limit(pageSize)
            .select('name isMale age phone email createTime')
            .exec((err, data) => {
                if(err){
                    res.json({code: 'error', message: '系统错误！'})
                }
                else{
                    res.json({code: 'success', data:  {
                            page, 
                            pageCount, 
                            // 调用getPages
                            pages:getPages(page, pageCount), 
                            students: data.map(m => {
                                m = m.toObject()
                                m.id = m._id.toString()
                                delete m._id
                                // 使用格式化函数将日期时间转换成字符串
                                m.createTime = formatTime(m.createTime)
                                
                                return m;
                            })
                        }   
                    })
                }
            })
        }
    })
})


module.exports = route;