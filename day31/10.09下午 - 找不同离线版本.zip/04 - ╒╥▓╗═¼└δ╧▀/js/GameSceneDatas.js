define(function (require) { 
    return [
        {
            src: 'images/1.jpg',
            seconds: 45, 
            diffs: [
                {
                    center: {x: 494, y: 402},
                    radius: 48 
                },
                {
                    center: {x: 622, y: 413},
                    radius: 39
                },
                {
                    center: {x: 662, y: 76},
                    radius: 33
                },
                {
                    center: {x: 791, y: 75},
                    radius: 42
                },
                {
                    center: {x: 864, y: 121},
                    radius: 30
                }]
        },
        {
            src: 'images/2.jpg',
            seconds: 30, 
            diffs: [
                {
                    center: {x: 566, y: 420},
                    radius: 48 
                },
                {
                    center: {x: 560, y: 104},
                    radius: 42
                },
                {
                    center: {x: 635, y: 373},
                    radius: 33
                },
                {
                    center: {x: 723, y: 424},
                    radius: 33
                },
                {
                    center: {x: 862, y: 406},
                    radius: 30
                }]
        },
        {
            src: 'images/3.jpg',
            seconds: 20, 
            diffs: [
                {
                    center: {x: 85, y: 395},
                    radius: 30 
                },
                {
                    center: {x: 379, y: 338},
                    radius: 35
                },
                {
                    center: {x: 629, y: 415},
                    radius: 33
                },
                {
                    center: {x: 707, y: 393},
                    radius: 35
                },
                {
                    center: {x: 869, y: 385},
                    radius: 30
                }]
        }
    ]
})
