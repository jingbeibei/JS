// 集合构造函数,支持2种传参形式
function Set(arr){
    var items = [];

    // 检查第1个参数是否是数组
    // 1 instanceof 2表示1是否是2的一个实例,结果是布尔值
    if(arr instanceof Array){
        items = arr;
    }else{
        // es6 新特性中 Array 类多了一个静态方法 from
        // 作用是将一个 ArrayLike 对象或者 Iterable 对象转换成一个 Array
        // http://www.tuicool.com/articles/QZJvA3R
        items = [].concat(Array.from(arguments));
    }
    // 调用排重方法,排重后的集合放入this.items
    this.items = Set.unique(items);
}

// 排重方法,即排除集合中重复的元素,它是一个类方法
Set.unique = function(arr){
    // 定义空数组用来保存结果
    var result = [];
    // 数组长度
    var length = arr.length;
    // 遍历arr
    for(var i = 0; i < length; i++){
        var a = arr[i];
        for(var j = i + 1; j < length; j++){
            var b = arr[j];
            // 如果a和b相等,跳出循环
            if (a === b){
                break;
            }else{
                if(j == length - 1){
                    // 如果a和b不相等,把a放入result
                    result.push(a);
                }
            }
        }
    }
    // 数组的最后一个元素放入result
    result.push(arr[length - 1]);
    // 返回result
    return result;
}

// 重写toString()方法
Set.prototype.toString = function(){
    return '{' + this.items.toString() + '}';
}

// 判断2个集合是否相等:元素个数相同,不分顺序
Set.prototype.equals = function(set){
    // set instanceof Set判断set是否是Set的一个实例
    // 判断set是否由Set构造函数创建,不是则返回false
    if(set instanceof Set){
        var arr1 = this.items;
        var arr2 = set.items;
        // 判断内部的元素个数是否相等,不相等则返回false
        if(arr1.length == arr2.length){
            // 合并排重后,元素个数仍然相等则集合相等
            var arr = Set.unique(arr1.concat(arr2));
            return arr.length == arr1.length;
        }else return false;
    }else return false;
}

// 并集:合并
Set.prototype.union = function(set){
    var result = this.items.concat(set.items);
    return new Set(result);
}

// 交集:求相同
Set.prototype.intersection = function(set){
    var arr1 = this.items;
    var arr2 = set.items;
    var result = [];

    for(var i = 0; i < arr1.length; i++){
        var a = arr1[i];
        for(var j = 0; j < arr2.length; j++){
            var b = arr2[j];
            if(a === b) result.push(a);
        }
    }
    return new Set(result);
}

// 差集:减去 this - set,从this中排除set中的元素
Set.prototype.difference = function(set){
    var arr1 = this.items;
    var arr2 = set.items;
    var result = [];

    for(var i = 0; i < arr1.length; i++){
        var a = arr1[i];
        for(var j = 0; j < arr2.length; j++){
            var b = arr2[j];
            if(a === b){
                break;
            }else{
                if(j == arr2.length - 1) result.push(a);
            }
        }
    }
    return new Set(result);
}