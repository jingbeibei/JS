// 之前常用的导入模块的代码
// const fs = require('fs')
// 对比着写就是：
const Set = require('./Set.js');

// console.log('require的返回值是：' + Set)
console.dir(Set);

// 使用require()方法导入【./set.js】得到是 {} 对象
// 如果在 Set.js 中使用 module.exports 导出一个对象
// 则require()方法将得到这个对象


// 在浏览器中可以使用<script>标签导入js,因为浏览器支持HTML语言
// Node.js不认识HTML，所以也不能使用<script>
// Node.js使用require()方法导入其它js文件

// require()方法实际是module对象的一个方法，即module.require()
// module即模块，Node.js将每一个js文件都视为模块

// 每一个正在执行的js中都有一个module对象
// module表示当前正在执行的模块

// console.log(module.filename);

// console.log(module.children);


// 关于require()方法中js路径的说明：
// 如果加载模块不是安装在node_modules文件夹中的模块
// 需在以./   ../  开头
// ./表示当前目录
// ../表示父级目录,即上一级目录
// ../../表示文件所在目录的上上级目录

// 如果加载的模块是通过npm安装的模块，则不加./   ../
// node会自动查找当前文件夹，上级文件夹，上上级文件夹，直到根目录



/*------------------构造函数-----------------*/

var set1 = new Set(1, 2, 4, 6, 3, 2, 6, 8, 2)
console.assert(set1.equals(new Set(1,2,4,6,3,8)), '创建集合错误')

var set2 = new Set(2,4,6,8,9)
console.assert(set2.equals(new Set(2,4,6,8,9)), '创建集合错误')

console.log('构造函数测试完成')

/*------------------并集-----------------*/

var set3 = set1.union(set2)

console.assert(set3 instanceof Set, '并集计算结果不是集合')
console.assert(set3.equals(new Set(1,2,4,6,3,8,9)), '并集计算错误')
console.assert(set1.equals(new Set(1,2,4,6,3,8)), '并集计算后集合1应该是不变的')
console.assert(set2.equals(new Set(2,4,6,8,9)), '并集计算后集合2应该是不变的')

console.log('并集测试完成')

/*------------------交集-----------------*/

var set4 = set1.intersection(set2)

console.assert(set4 instanceof Set, '交集计算结果不是集合')
console.assert(set4.equals(new Set(2,4,6,8)), '交集计算错误')
console.assert(set1.equals(new Set(1,2,4,6,3,8)), '交集计算后集合1应该是不变的')
console.assert(set2.equals(new Set(2,4,6,8,9)), '交集计算后集合2应该是不变的')

console.log('交集测试完成')

/*------------------差集-----------------*/

var set5 = set1.difference(set2)

console.assert(set5 instanceof Set, '差集计算结果不是集合')
console.assert(set5.equals(new Set(1,3)), '差集计算错误')
console.assert(set1.equals(new Set(1,2,4,6,3,8)), '差集计算后集合1应该是不变的')
console.assert(set2.equals(new Set(2,4,6,8,9)), '差集计算后集合2应该是不变的')

var set6 = set2.difference(set1)

console.assert(set6 instanceof Set, '交换差集计算结果不是集合')
console.assert(set6.equals(new Set(9)), '交换差集计算错误')
console.assert(set1.equals(new Set(1,2,4,6,3,8)), '交换差集计算后集合1应该是不变的')
console.assert(set2.equals(new Set(2,4,6,8,9)), '交换差集计算后集合2应该是不变的')

console.log('差集测试完成')
