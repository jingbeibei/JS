// 

// send:服务器的响应消息
// 用来向客户端发送响应信息,该方法在多个地方调用
function send(res, code, message, data){
    res.status(200).json({code, message, data})
}

// 判断用户是否登录的方法
function sign(req, res, next){
    // 如果cookies中有petname表示用户已经登录
    if(req.cookies.petname){
        next()
    }
    else{
        // 如果req.xhr为true表示没有登录
        if(req.xhr){
            // 发送登录错误的消息
            send(res, 'signin error', '请重新登录...')
        }
        else{
            // 重定向到"登录"页面
            res.redirect('/user/signin')
        }
    }
}

// 导出多个函数，以下3种写法都可以
// 1
// module.exports = {send: send, sign: sign}
//==========================================
// 2
module.exports = {send, sign}
//==========================================
// 3
// exports.send = send
// exports.sign = sign

