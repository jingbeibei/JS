const   exp = require('express'),
        bodyParser = require('body-parser'),
        cookieParser = require('cookie-parser'),
        fs = require('fs'),
        // 处理文件上传
        uploads = require('./multer.js'),
        // 模板的辅助方法
        template = require('./template'),
        util = require('./utilities'),
        app = exp()
         
 
app.use(exp.static('www'))
app.use(bodyParser.urlencoded({extended:true}))
app.use(cookieParser())

app.engine('html', template.__express)
app.set('view engine', 'html')

/*--------------------注册--------------------*/

app.get('/user/register', (req, res) => {
    res.render('user/register', {
        title: '注册'
    })
})

app.post('/api/user/register', (req, res) => {
    req.body.ip = req.ip
    req.body.time = new Date()
    // function send(){

    // }
    function saveFile(){
        var fileName = `users/${req.body.petname}.txt`
        
        fs.exists(fileName, exists => {
            if(exists){
                util.send(res, 'registered', '用户名已经注册过了！')
            }
            else{
                fs.appendFile(fileName, JSON.stringify(req.body), err => {
                    if(err){
                        util.send(res, 'file error', '抱歉，系统错误...')
                    }
                    else{
                        util.send(res, 'success', '恭喜，注册成功！请登录...')
                    }
                })
            }
        })
    }
   
    fs.exists('users', exists => {
        if(exists){
            saveFile()
        }
        else{
            fs.mkdir('users', err => {
                if(err){
                    util.send(res, 'file error', '抱歉，系统错误...')
                }
                else{
                    saveFile()
                }
            })
        }
    })
})

/*--------------------登录--------------------*/

app.get('/user/signin', (req, res) => {
    res.render('user/signin', {
        title: '登录',
        rightNav: 'register'
    })
})

app.post('/api/user/signin', (req, res) => {
    var fileName = `users/${req.body.petname}.txt`
    
    fs.exists(fileName, exists => {
        if(exists){
            fs.readFile(fileName, (err, data) => {
                if(err){
                    util.send(res, 'file error', '抱歉，系统错误...')
                }
                else{
                    var user = JSON.parse(data)
                    if(user.password == req.body.password){
                        
                        res.cookie('petname', req.body.petname)
                        // 
                        
                        util.send(res, 'success', '登录成功...')
                    }
                    else{
                        util.send(res, 'signin error', '用户名或密码错误！')
                    }
                }
            })
        }
        else{
            util.send(res, 'register error', '用户名未注册！')
        }
    })
})

/*--------------------退出--------------------*/

app.get('/user/signout', (req, res) => {
    res.clearCookie('petname')
    res.redirect('/')
    // 在服务端控制浏览器页面跳转
    // redirect('/')重定向到首页
})

/*--------------------提问--------------------*/
// 添加util.sign请求处理函数
// 判断用户是否登录，如果未登录则重定向到登录页，如果已登录则交给后面箭头函数处理
app.get('/ask', util.sign, (req, res) => {
    res.render('ask', {
        title: '提问'
    })
})

app.post('/api/ask', util.sign, (req, res) => { 
    var petname = req.cookies.petname
     
    if(!petname){
        util.send(res, 'signin error', '请重新登录...')
        return
    }
    
    var time = new Date()
    
    req.body.petname = petname
    req.body.ip = req.ip
    req.body.time = time
    
    function saveFile(){
        var fileName = `questions/${time.getTime()}.txt`
        
        fs.appendFile(fileName, JSON.stringify(req.body), err => {
            if(err){
                util.send(res, 'file error', '抱歉，系统错误...')
            }
            else{
                util.send(res, 'success', '问题提交成功！')
            }
        })
    }
    
    fs.exists('questions', exists => {
        if(exists){
            saveFile()
        }
        else{
            fs.mkdir('questions', err => {
                if(err){
                    util.send(res, 'file error', '抱歉，系统错误...')
                }
                else{
                    saveFile()
                }
            })
        }
    })
})

/*--------------------头像--------------------*/

app.get('/user/photo', util.sign, (req, res) => {
    res.render('user/photo', {
        title: '修改头像'
    })
})

app.post('/api/user/photo', util.sign, uploads.single('photo'), (req, res) => {
    res.status(200).json({ code: 'success', message: '上传成功' })
})

/*--------------------首页--------------------*/

app.get('/', (req, res) => {
    function readFiles(i, files, questions, complete){
        if(i < files.length){
            fs.readFile(`questions/${files[i]}`, (err, data) => {
                if(!err){
                    questions.push(JSON.parse(data))
                }
                readFiles(++i, files, questions, complete)
            })
        }
        else{
            complete()
        }
    }
    
    fs.readdir('questions', (err, files) => {
        if(err){
            // 跳转到错误页
        }
        else{
            files = files.reverse()
            var questions = []
            
            readFiles(0, files, questions, () => {
                // views下的index.html
                res.render('index', {
                    user: req.cookies.petname,
                    questions
                })
            })
        }
    })
})

/*--------------------回答--------------------*/

app.get('/answer/:question', util.sign, (req, res) => {
    res.render('answer', {
        title: '回答',
        question: req.params.question
    })
})

app.post('/api/answer', util.sign, (req, res) => { 
    var petname = req.cookies.petname
     
    if(!petname){
        util.send(res, 'signin error', '请重新登录...')
        return
    }
    console.log(req.body)
    var filename = `questions/${req.body.question}.txt`
    
    req.body.petname = petname
    req.body.ip = req.ip
    req.body.time = new Date()
    
    fs.readFile(filename, (err, data) => {
        if(err){
            util.send(res, 'file error', '抱歉，系统错误...')
        }
        else{
            var question = JSON.parse(data)
            if(!question.answers) question.answers = []
            
            question.answers.push(req.body)
            
            fs.writeFile(filename, JSON.stringify(question), err => {
                if(err){
                    util.send(res, 'file error', '抱歉，系统错误...')
                }
                else{
                    util.send(res, 'success', '回答提交成功！')
                }
            })
        }
    })
})

/*--------------------监听--------------------*/

app.listen(3000, () => console.log('正在运行...'))