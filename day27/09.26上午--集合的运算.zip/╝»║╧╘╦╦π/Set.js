// Set.js

// 表示集合的构造函数Set,支持两种传参形式
// 1 arr表示数组
// 2 非数组
function Set(arr){
    var items = [];

    // 1 instanceof 2:判断1是否是2的一个实例
    // 判断结果是布尔值
    if(arr instanceof Array){
        items = arr;
    }else{
        items = [].concat(Array.from(arguments));
    }
    // this.items表示是排重后的集合
    this.items = Set.unique(items);
}

// 向Set中添加一个方法
// 排重方法:排除集合当中重复的元素
Set.unique = function(arr){
    var result = [];
    var length = arr.length;

    // 遍历arr
    for(var i = 0;  i < length; i++){
        var a = arr[i];
        for(var j = i + 1; j < length; j++){
            var b = arr[j];
            // 比较a和b
            if(a === b){
                break;
            }else{
                // 没有重复元素时把当前元素放入新数组
                if(j == length - 1){
                    result.push(a);
                }
            }
        }
    }
    // 集合的最后一个元素放入result
    result.push(arr[length - 1]);
    return result;
}

// 判断2个集合是否相等,元素个数相同,不分顺序
Set.prototype.equals = function(set){
    // 判断set是否是由构造函数Set创建,不是的话返回false
    if(set instanceof Set){
        var arr1 = this.items;
        // set表示传入的参数
        var arr2 = set.items;

        // 判断内部元素个数是否相等,不相等就返回false
        if(arr1.length == arr2.length){
            // 合并arr1和arr2再排重
            // 如果合并排重后元素个数仍然相等那么这两个集合是相等的
            var arr = Set.unique(arr1.concat(arr2));
            // 
            return arr.length == arr1.length;
        }else return false;
    }else return false;
}

// 课堂作业:完成以下集合运算
// 1 并集
Set.prototype.union = function(set){
    //...
}

// 2 交集
Set.prototype.intersection = function(set){
    //...
}

// 3 差集
Set.prototype.difference = function(set){
    //...
}