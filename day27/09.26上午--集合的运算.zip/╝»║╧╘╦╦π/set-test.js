// set-test.js

// 创建一个构造函数的实例
var set1 = new Set(1, 2, 4, 6, 3, 2, 6, 8, 2);
// console.assert()表示一个断言函数
// 参数1表示一个条件
// 参数2表示出错信息,如果参数1条件不成立的话会输出该信息
console.assert(set1.equals(new Set(1, 2, 4, 6, 3, 8)), '创建集合错误!');

var set2 = new Set(2, 4, 6, 8, 9);
console.assert(set2.equals(new Set(2, 4, 6, 8, 9)), '创建集合错误');
console.log('构造函数测试完成');