// mongoose.js 连接数据库

// 加载mongoose模块
const mongoose = require('mongoose');

// 连接数据库
// 数据库名为:zhongbei-students
mongoose.connect('mongodb://localhost/zhongbei-students');
// 获取当前数据库连接
const db = mongoose.connection;

// 监听数据库连接事件
db.on('error', err=>console.error('数据库连接失败', err));
db.on('open', ()=>{console.log('成功打开数据库,人品很好!!!')});

// 创建数据模型
// 参数1: 模型的名称,也是数据库中集合的名称
// 参数2: 描述了数据的形状,即数据中有哪些属性,属性的类型等
const Student = mongoose.model('students', {
    name: String,
    age: Number,
    isMale: Boolean,
    phone: String,
    email: String,
    description: String,
    ip: String,
    createTime: Date,
    updateTime: Date
});

// 导出供外部使用
module.exports = Student;
