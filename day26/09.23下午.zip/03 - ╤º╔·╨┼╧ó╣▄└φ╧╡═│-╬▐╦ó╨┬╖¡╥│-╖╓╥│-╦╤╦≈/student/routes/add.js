// add.js

const express = require('express');
const route = express.Router();

route.get('/', (req, res)=>{
    res.render('add');

})

module.exports = route;