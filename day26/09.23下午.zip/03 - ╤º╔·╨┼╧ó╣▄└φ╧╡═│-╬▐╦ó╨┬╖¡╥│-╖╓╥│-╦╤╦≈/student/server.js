// server.js

// 
const express = require('express');
const bodyParser = require('body-parser');
const template = require('art-template');
// 加载同一目录下的mongoose.js文件
const Student = require('./mongoose');

// 创建一个express的实例
const app = express();

// 禁用模板缓存
template.config('cache', false);

// 创建一个模板引擎用art-template渲染页面
// 默认不是用art-template渲染
app.engine('html', template.__express);
// 指定渲染views下的html文件
app.set('view engine', 'html');

// 指定静态文件目录为wwwroot
app.use(express.static('wwwroot'));
// 指定bodyParser解析url编码的数据
app.use(bodyParser.urlencoded({extended:true}));

// 使用路由技术把代码分散到多个文件中
// 路由技术:即把代码模块化,优点是:
// 1.每个文件中的代码都很少,便于阅读和修改
// 2.将代码分散到不同的文件中可以多人同时开发
app.use('/api/index', require('./routes/api/index'));
app.use('/api/student', require('./routes/api/student'));
app.use('/edit', require('./routes/edit'));
app.use('/add', require('./routes/add'));

// 
app.listen(3000, ()=>{console.log('正在运行...')});