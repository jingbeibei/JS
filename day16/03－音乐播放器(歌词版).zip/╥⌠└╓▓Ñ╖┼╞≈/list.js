var list = [
    {
        name: '传奇',
        singer: '王菲',
        src: 'mp3/传奇.mp3',
        cover: 'images/wf.png'
    },
    {
        name: '知道不知道',
        singer: '刘若英',
        src: 'mp3/知道不知道.mp3',
        cover: 'images/lry.jpg'
    }
]

var lrcs = {}