node_modules: nodejs的模块文件夹
wwwroot：放置网站的目录
app.js: 服务器的主程序(入口文件)
package.json: 项目的配置文件
