var img = document.getElementById('tom');
var player = document.getElementById('player');
var w = document.documentElement.clientWidth;
var h = document.documentElement.clientHeight;
// 是否正在动画
var playing = false;

window.onresize = function(){
    w = document.documentElement.clientWidth;
    h = document.documentElement.clientHeight; 
}

function play(name, total, startAt) {
    // 如果正在动画 return
    if(playing) return;
    // playing可以作为是否正在动画的一个判断条件
    // 播放动画时，把playing改为true，如果在动画过程中再次点击屏幕
    // 此时又会调用play函数,进入函数体后首先判断playing的值，此时已经是true
    // 是true时会return，所以就不会产生多次相同的动画了
    playing = true;

    var i = 0;
    animate();

    function animate() {
        var src = name + '/' + name + '_' + (i < 10 ? + '0' : '') + i + '.jpg'
        img.src = src;

        if (i < total) {
            timer = setTimeout(animate, 100)

            if (i == startAt) {
                player.src = 'sounds/' + name + '.m4a'
                player.play()
            }
            if (name == 'drink' && i == 10) { // drink 需要2个音频
                player.src = 'sounds/pour.m4a'
                player.play()
            }
            if (name == 'knockout' && i == 0) {
                player.src = 'sounds/fall.m4a'
                player.play()
            }
            i++;
        }
        else{
            playing = false;
        }
    }
}
// play('angry', 25, 0)
// play('angry', 25, 0)

function action(event) {
    var x = event.pageX * 360 / w
    var y = event.pageY * 640 / h

    // alert('x:' + x + ',y:' + y)

    if (x > 140 && x < 225 && y > 400 && y < 450) {
        play('angry', 25, 0)
    }

    if (x > 119 && x < 245 && y > 465 && y < 565) {
        play('stomach', 33, 0)
    }

    if (x > 155 && x < 210 && y > 190 && y < 230) {
        play('knockout', 80, 13)
    }

    if (x > 137 && x < 235 && y > 250 && y < 280) {
        if (x < 185)
            play('eat', 39, 0)
        else
            play('drink', 80, 30)
    }

    if (x > 124 && x < 240 && y > 160 && y < 190) {
        play('cymbal', 12, 0)
    }

    if (x > 246 && x < 280 && y > 490 && y < 580) {
        play('fart', 27, 0)
    }

    if (x > 80 && x < 120 && y > 110 && y < 195) {
        play('scratch', 55, 15)
    }

    if (x > 240 && x < 290 && y > 110 && y < 200) {
        play('pie', 23, 12)
    }

    if (x > 125 && x < 175 && y > 570 && y < 620) {
        play('foot_right', 29, 0)
    }

    if (x > 180 && x < 230 && y > 570 && y < 620) {
        play('foot_left', 29, 0)
    }
}