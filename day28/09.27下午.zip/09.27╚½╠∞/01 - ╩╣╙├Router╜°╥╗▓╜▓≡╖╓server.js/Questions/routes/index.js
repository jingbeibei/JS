const   exp = require('express'),
        fs = require('fs'),
        util = require('../utilities')
        
const router = exp.Router()


router.get('/', (req, res) => {
    
    function readFiles(i, files, questions, complete){
        if(i < files.length){
            fs.readFile(`questions/${files[i]}`, (err, data) => {
                if(!err){
                    questions.push(JSON.parse(data))
                }
                readFiles(++i, files, questions, complete)
            })
        }
        else{
            complete()
        }
    }
    
    fs.readdir('questions', (err, files) => {
        if(err){
            res.render('error')
        }
        else{
            files = files.reverse()
            var questions = []
            
            readFiles(0, files, questions, () => {
                // 渲染views/index.html
                res.render('index', {
                    user: req.cookies.petname,
                    questions
                })
            })
        }
    })
})

module.exports = router