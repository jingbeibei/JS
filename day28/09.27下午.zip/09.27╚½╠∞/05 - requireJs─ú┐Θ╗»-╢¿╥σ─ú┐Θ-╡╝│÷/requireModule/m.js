
// define是require.js提供的模块定义函数
// 在这个函数中可以定义模块，方法是：
// 调用define，给它传一个函数,模块的所有代码都写在这个函数中，
// 模块代码在函数作用域中，不会污染/干扰全局作用域 

// 函数作用域存在的时间非常短，而且在外面也无法得到
// 函数作用域内部的内容，所以需要使用return将
// 需要导出的内容返回到函数外部

define(function(){
    // 函数作用域
    // 调用函数时，代码执行到函数内部时创建函数作用域
    // 函数的代码执行完毕后，函数作用域会立刻消毁
    // 函数作用域消毁时，函数内部定义的变量和函数都会消毁
    
    var number1 = 11
    var number2 = 12
    var hello = function(){
        alert('Hello From M:' + number1)
    }
    
    // return将一个值返回给函数的调用者
    // return返回的值会跳出函数作用域
    // return返回的值会比函数作用域生存的时间长
    return {
        number1: number1,
        number2: number2,
        hello: hello
    }
})


