
// 让requireJs虚拟出来一个module
// module通过传参数的方式进入函数作用域
// 第1个参数用来指示requireJs在调用后面的函数时注入module参数

define(['require', 'module'], function(require, module){
    
    // requireJs中也可像NodeJs中一样
    // 使用require加载其它js模块
    var exports = require('exports')
    // require()可以有多个，不分先后顺序
    // 而且还可以和其它代码混写
    
    // require()仍然是异步并行加载的
    // requireJs在执行模块定义函数时，
    // 会先用正则表达式提取所有require()语句，
    // 提取后异步并行加载这些js模块，加载成功后
    // 再调用模块定义函数
    
    var number1 = 21
    var number2 = 22
    var hello = function(){
        console.log('Hello From M2')
    }
    
    // requireJs支持NodeJs中导出模块的写法
    // module.exports = {
    //     number1: number1,
    //     number2: number2,
    //     hello: hello
    // }
    
    exports.number1 = number1
    exports.number2 = number2
    exports.hello = hello
})