// 使用require可以加载m.js，m.js加载成功后
// 可以在回调函数中得到m.js中返回的内容
// require(1, 2)
// 参数1: 是一个数组，表示所依赖的模块
// 参数2: 是一个回调函数，当前面指定的模块都加载成功后，它将被调用--
// --加载的模块会以参数形式传入该函数，从而在回调函数内部就可以使用这些模块
require(['m', 'm2'], function(mReturn, m2){
    console.log(mReturn);
    console.log(m2);

    console.log(mReturn.number1)
    console.log(mReturn.number2)
    mReturn.hello()
    
    console.log(m2.number1)
    console.log(m2.number2)
    m2.hello()   
})

// 参考
// http://www.tuicool.com/articles/7JBnmy
// http://www.ruanyifeng.com/blog/2012/11/require_js.html
