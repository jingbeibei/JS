console.log('b loading')

var number1 = 1
var number2 = 2

// exports.number1 = number1
// exports.number2 = number2

// 如果想在b.js之外使用number1和number2
// 只能将它们【导出】

module.exports = {number1, number2}