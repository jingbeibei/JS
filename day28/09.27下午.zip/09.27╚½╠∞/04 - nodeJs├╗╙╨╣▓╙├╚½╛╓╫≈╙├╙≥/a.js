console.log('a loading')

var number1 = 1
var number2 = 2