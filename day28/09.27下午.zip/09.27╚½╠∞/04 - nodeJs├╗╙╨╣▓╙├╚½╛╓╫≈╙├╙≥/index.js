const a = require('./a')

// NodeJs中没有共用的全局作用域
// 所以下面2行代码会报错
// console.log(a.number1)
// console.log(a.number2)


const b = require('./b')

console.log(b.number1)
console.log(b.number2)