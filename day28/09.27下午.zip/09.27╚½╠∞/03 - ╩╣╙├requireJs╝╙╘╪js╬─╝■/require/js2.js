// js2.js
console.log('js2 loading')

var number2 = 2

function hello2(){
    console.log('Hello From Js2')
}