// js1.js
console.log('js1 loading')

var number1 = 1

function hello1(){
    console.log('Hello From Js1')
}

require(['./js/jsA', './js/jsB', './js/jsC'])