// js3.js
console.log('js3 loading')


var number3 = 3

function hello3(){
    console.log('Hello From Js3')
}

function hello2(){
    alert('看看会不会执行！')
}