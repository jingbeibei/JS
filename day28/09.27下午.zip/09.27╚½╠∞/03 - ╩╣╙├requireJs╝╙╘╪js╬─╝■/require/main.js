// 参考C语言以main函数作为入口，requireJs使用data-main加载第1个js文件

console.log('main loading')


// 同时加载js1和js2，也可加载更多的js文件
// 脚本全部加载完成后，会调用第2参数指定的回调函数

// require.js会自动在<head>标签中注入<script>标签
// require.js添加在<script>标签带有async属性
// async属性会使浏览器同时开始异步加载js文件

// 使用require.js可以很方便地导入js文件，但是需要解决js
// 文件中变量名、方法名与其它js文件中变量名方法名冲突的问题
// 造成这个问题的原因是：
// 浏览器端js存在共用的全局作用域，全局变量名、方法名有可能被覆盖掉！

// NodeJs中每一个js文件都是一个独立作用域，不存在
// 共用的全局作用域，NodeJs中的js文件是相互隔离的
// js文件之间只能通过模块导出的方法相互使用
require(['js1.js', 'js2.js', 'js3.js'], function(){
    console.log('js1/2/3 loaded')
    
    var total = number1 + number2 + number3
    console.log(total)
    
    hello1()
    hello2()
    hello3()
})

console.log('after require')
