const   exp = require('express'),
        fs = require('fs'),
        util = require('../utilities')
        
const router = exp.Router()


router.get('/answer/:question', util.sign, (req, res) => {
    res.render('answer', {
        title: '回答',
        question: req.params.question
    })
})

router.post('/api/answer', util.sign, (req, res) => { 
    var petname = req.cookies.petname
    var filename = `questions/${req.body.question}.txt`
    
    req.body.petname = petname
    req.body.ip = req.ip
    req.body.time = new Date()
    
    fs.readFile(filename, (err, data) => {
        if(err){
            util.send(res, 'file error', '抱歉，系统错误...')
        }
        else{
            var question = JSON.parse(data)
            if(!question.answers) question.answers = []
            
            question.answers.push(req.body)
            
            fs.writeFile(filename, JSON.stringify(question), err => {
                if(err){
                    util.send(res, 'file error', '抱歉，系统错误...')
                }
                else{
                    util.send(res, 'success', '回答提交成功！')
                }
            })
        }
    })
})


module.exports = router