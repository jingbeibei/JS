const   exp = require('express'),
        fs = require('fs'),
        uploads = require('../../multer'),
        util = require('../../utilities')
// Express提供了一个叫做Router的对象,可以把Router直接传递给app.use       
const router = exp.Router()

router.get('/user/photo', util.sign, (req, res) => {
    res.render('user/photo', {
        title: '修改头像'
    })
})

router.post('/api/user/photo', util.sign, uploads.single('photo'), (req, res) => {
    util.send(res, 'success', '上传成功')
})
// 导出路由对象
module.exports = router