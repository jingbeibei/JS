// 定义一个工资计算模块
// 这个模块导出一个函数，这个函数接收3个参数
// 分别表示：基本工资，绩效工资，奖金
// 这个函数通过计算返回一个对象：
// {
//     total: 12000,
//     shebao: {
//         yiliao: 300,
//         ...
//         total: 500
//     }
//     jishui: 11500,
//     shui: 1000,
//     shifa: 10500
// }

// requireJs定义模块的步骤：
// 1、写一个define函数调用
// 2、在define中写一个函数作用域
// 3、在函数作用域写模块代码
// 4、将指定的内容导出

define(function(){
    function calc(jishu, jixiao, jiangjin){
        var total = jishu + jixiao + jiangjin;
        // 其它数据计算
        
        
        return {
            total: total
            //其它数据
        }
    }
    
    return calc;
});

// define(['module'], function(module){
//     function calc(jishu, jixiao, jiangjin){
//         var total = jishu + jixiao + jiangjin
//         // 其它数据计算
        
//         return {
//             total: total
//         }
//     }
    
//     module.exports = calc
// })

// define(['exports'], function(exports){
//     function calc(jishu, jixiao, jiangjin){
//         var total = jishu + jixiao + jiangjin
//         // 其它数据计算
        
//         return {
//             total: total
//         }
//     }
    
//     // 直接给exports赋值是不能导出的
//     // exports = calc
    
//     // 使用exports只能以属性的方式导出内容
//     // 使用时也要使用导出对象的属性如：$$.calc()
//     exports.calc = calc
// })