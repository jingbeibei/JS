require(['jquery', 'gongzi'], function($, $$){
    // 监听计算按扭点击事件
    // 当按扭被点击时收集文本框数据
    // 使用$$计算工资数据
    // 将工资数据使用$更新到页面上
    
    // 监听form表单的input事件，当用户输入时
    // 隐藏计算结果区域
    
    
    console.dir($$)
    
    $('button').click(function(){
        var jishu = $('#jishu').val(),
            jixiao = $('#jixiao').val(),
            jiangjin = $('#jiangjin').val()
            
        jishu = parseFloat(jishu) || 0
        jixiao = parseFloat(jixiao) || 0
        jiangjin = parseFloat(jiangjin) || 0
        
        var data = $$(jishu, jixiao, jiangjin)
        
        $('#zonge').text(data.total.toFixed(2))
        //更新计算结果的其它代码
        
        $('section').slideDown()
    })
    
    $('form').on('input', function(){
        $('section').fadeOut()
    })
})